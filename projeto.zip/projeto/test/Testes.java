public class Testes {
    public static void main(String[] args) {
        Funcionario administrativo = new FuncionarioAdministrativo(
                "Ana", "11122233344", 1, 3000.0, 450.0);
        Funcionario desenvolvedor = new Desenvolvedor(
                "Bruno", "55566677788", 2, 4000.0, NivelExperiencia.PLENO);

        igual(3450.0, administrativo.calcularRemuneracao(), "remuneração administrativa");
        igual(4800.0, desenvolvedor.calcularRemuneracao(), "remuneração de desenvolvedor pleno");
        verdadeiro(administrativo.exibirInformacoes().contains("Produtividade"), "exibição administrativa");
        verdadeiro(desenvolvedor.exibirInformacoes().contains("PLENO"), "exibição do desenvolvedor");

        CadastroFuncionarios cadastro = new CadastroFuncionarios();
        cadastro.cadastrar(administrativo);
        cadastro.cadastrar(desenvolvedor);
        verdadeiro(cadastro.buscar(1) == administrativo, "busca por matrícula");
        verdadeiro(cadastro.buscar("55566677788") == desenvolvedor, "busca por CPF");
        verdadeiro(cadastro.buscar(99) == null, "matrícula inexistente");
        verdadeiro(cadastro.listar().size() == 2, "listagem");

        erro(() -> cadastro.cadastrar(new FuncionarioAdministrativo(
                "Outra", "99988877766", 1, 2000.0, 0.0)), "matrícula duplicada");
        erro(() -> cadastro.cadastrar(new FuncionarioAdministrativo(
                "Outra", "11122233344", 3, 2000.0, 0.0)), "CPF duplicado");
        erro(() -> cadastro.cadastrar(new FuncionarioAdministrativo()),
                "funcionário incompleto");

        FuncionarioAdministrativo novo = new FuncionarioAdministrativo();
        novo.setNome("Carla");
        novo.setCpf("12345678901");
        novo.setMatricula(3);
        novo.setSalarioBase(2500.0);
        novo.setAdicionalProdutividade(200.0);
        igual(2700.0, novo.calcularRemuneracao(), "construtor vazio e setters");
        erro(() -> novo.setSalarioBase(-1), "salário negativo");

        System.out.println("Todos os testes passaram.");
    }

    private static void igual(double esperado, double atual, String descricao) {
        if (Math.abs(esperado - atual) > 0.0001) {
            throw new AssertionError(descricao + ": esperado " + esperado + ", obtido " + atual);
        }
    }

    private static void verdadeiro(boolean condicao, String descricao) {
        if (!condicao) {
            throw new AssertionError(descricao);
        }
    }

    private static void erro(Runnable acao, String descricao) {
        try {
            acao.run();
            throw new AssertionError("Era esperado erro: " + descricao);
        } catch (IllegalArgumentException esperado) {
            // A validação rejeitou o dado inválido.
        }
    }
}
