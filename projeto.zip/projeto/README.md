# Gestão de funcionários em Java

Aplicação de terminal para cadastrar, consultar e alterar funcionários administrativos e desenvolvedores. Os dados ficam em memória durante a execução.

## Executar

Requer JDK 17 ou superior. No PowerShell, a partir da raiz do projeto:

```powershell
javac -encoding UTF-8 -d out src\*.java
java -cp out Main
```

## Testar

```powershell
javac -encoding UTF-8 -d out src\*.java test\*.java
java -cp out Testes
```

## Regras de remuneração

- Administrativo: salário-base + adicional fixo de produtividade.
- Desenvolvedor: salário-base + 10% (JUNIOR), 20% (PLENO) ou 30% (SENIOR).

Os percentuais são uma escolha de exemplo, pois o enunciado não informa seus valores. A sobrecarga aparece em `buscar(int)` / `buscar(String)` e em `exibirInformacoes()` / `exibirInformacoes(boolean)`. As subclasses sobrescrevem o cálculo e a exibição. O cadastro usa referências `Funcionario` para guardar ambos os tipos.

Este exemplo usa `double` para simplificar o exercício; um sistema financeiro real deve usar `BigDecimal`. O CPF é validado apenas pelo formato de 11 dígitos, e não pelo cálculo dos dígitos verificadores.
