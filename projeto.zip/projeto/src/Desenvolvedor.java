import java.util.Objects;

public class Desenvolvedor extends Funcionario {
    private NivelExperiencia nivelExperiencia;

    public Desenvolvedor() {
        super();
    }

    public Desenvolvedor(String nome, String cpf, int matricula,
                        double salarioBase, NivelExperiencia nivelExperiencia) {
        super(nome, cpf, matricula, salarioBase);
        setNivelExperiencia(nivelExperiencia);
    }

    public NivelExperiencia getNivelExperiencia() {
        return nivelExperiencia;
    }

    public void setNivelExperiencia(NivelExperiencia nivelExperiencia) {
        this.nivelExperiencia = Objects.requireNonNull(nivelExperiencia, "Nível é obrigatório.");
    }

    @Override
    public double calcularRemuneracao() {
        return getSalarioBase() * (1 + nivelExperiencia.getPercentualAdicional());
    }

    @Override
    public String exibirInformacoes() {
        return "Desenvolvedor | " + super.exibirInformacoes()
                + " | Nível: " + nivelExperiencia;
    }
}
