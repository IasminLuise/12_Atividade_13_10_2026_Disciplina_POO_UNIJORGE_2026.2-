import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        CadastroFuncionarios cadastro = new CadastroFuncionarios();
        Scanner entrada = new Scanner(System.in);

        while (true) {
            System.out.println("\n1 - Cadastrar administrativo");
            System.out.println("2 - Cadastrar desenvolvedor");
            System.out.println("3 - Listar funcionários");
            System.out.println("4 - Consultar por matrícula");
            System.out.println("5 - Consultar por CPF");
            System.out.println("6 - Alterar funcionário");
            System.out.println("0 - Sair");
            System.out.print("Opção: ");

            String opcao = entrada.nextLine().trim();
            if (opcao.equals("0")) {
                break;
            }

            try {
                switch (opcao) {
                    case "1" -> cadastrarAdministrativo(entrada, cadastro);
                    case "2" -> cadastrarDesenvolvedor(entrada, cadastro);
                    case "3" -> listar(cadastro);
                    case "4" -> mostrar(cadastro.buscar(lerInteiro(entrada, "Matrícula: ")));
                    case "5" -> mostrar(cadastro.buscar(lerTexto(entrada, "CPF: ")));
                    case "6" -> alterar(entrada, cadastro);
                    default -> System.out.println("Opção inválida.");
                }
            } catch (IllegalArgumentException erro) {
                System.out.println("Erro: " + erro.getMessage());
            }
        }
    }

    private static void cadastrarAdministrativo(Scanner entrada, CadastroFuncionarios cadastro) {
        String nome = lerTexto(entrada, "Nome: ");
        String cpf = lerTexto(entrada, "CPF (11 dígitos): ");
        int matricula = lerInteiro(entrada, "Matrícula: ");
        double salario = lerDecimal(entrada, "Salário-base: ");
        double adicional = lerDecimal(entrada, "Adicional de produtividade: ");
        cadastro.cadastrar(new FuncionarioAdministrativo(nome, cpf, matricula, salario, adicional));
        System.out.println("Funcionário cadastrado.");
    }

    private static void cadastrarDesenvolvedor(Scanner entrada, CadastroFuncionarios cadastro) {
        String nome = lerTexto(entrada, "Nome: ");
        String cpf = lerTexto(entrada, "CPF (11 dígitos): ");
        int matricula = lerInteiro(entrada, "Matrícula: ");
        double salario = lerDecimal(entrada, "Salário-base: ");
        NivelExperiencia nivel = lerNivel(entrada);
        cadastro.cadastrar(new Desenvolvedor(nome, cpf, matricula, salario, nivel));
        System.out.println("Funcionário cadastrado.");
    }

    private static void listar(CadastroFuncionarios cadastro) {
        if (cadastro.listar().isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
            return;
        }
        for (Funcionario funcionario : cadastro.listar()) {
            mostrar(funcionario);
        }
    }

    private static void mostrar(Funcionario funcionario) {
        System.out.println(funcionario == null
                ? "Funcionário não encontrado."
                : funcionario.exibirInformacoes(true));
    }

    private static void alterar(Scanner entrada, CadastroFuncionarios cadastro) {
        Funcionario funcionario = cadastro.buscar(lerInteiro(entrada, "Matrícula: "));
        if (funcionario == null) {
            System.out.println("Funcionário não encontrado.");
            return;
        }

        System.out.println("1 - Nome | 2 - Salário-base | 3 - Adicional ou nível");
        String opcao = lerTexto(entrada, "Campo: ");
        switch (opcao) {
            case "1" -> funcionario.setNome(lerTexto(entrada, "Novo nome: "));
            case "2" -> funcionario.setSalarioBase(lerDecimal(entrada, "Novo salário-base: "));
            case "3" -> {
                if (funcionario instanceof FuncionarioAdministrativo administrativo) {
                    administrativo.setAdicionalProdutividade(
                            lerDecimal(entrada, "Novo adicional de produtividade: "));
                } else if (funcionario instanceof Desenvolvedor desenvolvedor) {
                    desenvolvedor.setNivelExperiencia(lerNivel(entrada));
                }
            }
            default -> {
                System.out.println("Campo inválido.");
                return;
            }
        }
        System.out.println("Funcionário atualizado.");
        mostrar(funcionario);
    }

    private static String lerTexto(Scanner entrada, String mensagem) {
        System.out.print(mensagem);
        return entrada.nextLine().trim();
    }

    private static int lerInteiro(Scanner entrada, String mensagem) {
        try {
            return Integer.parseInt(lerTexto(entrada, mensagem));
        } catch (NumberFormatException erro) {
            throw new IllegalArgumentException("Informe um número inteiro.");
        }
    }

    private static double lerDecimal(Scanner entrada, String mensagem) {
        try {
            return Double.parseDouble(lerTexto(entrada, mensagem).replace(',', '.'));
        } catch (NumberFormatException erro) {
            throw new IllegalArgumentException("Informe um número decimal.");
        }
    }

    private static NivelExperiencia lerNivel(Scanner entrada) {
        try {
            return NivelExperiencia.valueOf(
                    lerTexto(entrada, "Nível (JUNIOR, PLENO, SENIOR): ").toUpperCase());
        } catch (IllegalArgumentException erro) {
            throw new IllegalArgumentException("Nível deve ser JUNIOR, PLENO ou SENIOR.");
        }
    }
}
