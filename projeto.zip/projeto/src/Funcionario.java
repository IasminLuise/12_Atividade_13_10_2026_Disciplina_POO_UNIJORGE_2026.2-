public abstract class Funcionario {
    private String nome;
    private String cpf;
    private int matricula;
    private double salarioBase;

    protected Funcionario() {
    }

    protected Funcionario(String nome, String cpf, int matricula, double salarioBase) {
        setNome(nome);
        setCpf(cpf);
        setMatricula(matricula);
        setSalarioBase(salarioBase);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        if (nome == null || nome.isBlank()) {
            throw new IllegalArgumentException("Nome não pode ser vazio.");
        }
        this.nome = nome.trim();
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        if (cpf == null || !cpf.matches("\\d{11}")) {
            throw new IllegalArgumentException("CPF deve ter 11 dígitos.");
        }
        this.cpf = cpf;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        if (matricula <= 0) {
            throw new IllegalArgumentException("Matrícula deve ser positiva.");
        }
        this.matricula = matricula;
    }

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        if (!Double.isFinite(salarioBase) || salarioBase < 0) {
            throw new IllegalArgumentException("Salário-base deve ser um valor não negativo.");
        }
        this.salarioBase = salarioBase;
    }

    public abstract double calcularRemuneracao();

    public String exibirInformacoes() {
        return String.format("Nome: %s | CPF: %s | Matrícula: %d | Salário-base: R$ %.2f",
                nome, cpf, matricula, salarioBase);
    }

    // Sobrecarga: permite escolher se a remuneração aparece na consulta.
    public String exibirInformacoes(boolean incluirRemuneracao) {
        String informacoes = exibirInformacoes();
        return incluirRemuneracao
                ? informacoes + String.format(" | Remuneração: R$ %.2f", calcularRemuneracao())
                : informacoes;
    }
}
