public class FuncionarioAdministrativo extends Funcionario {
    private double adicionalProdutividade;

    public FuncionarioAdministrativo() {
        super();
    }

    public FuncionarioAdministrativo(String nome, String cpf, int matricula,
                                    double salarioBase, double adicionalProdutividade) {
        super(nome, cpf, matricula, salarioBase);
        setAdicionalProdutividade(adicionalProdutividade);
    }

    public double getAdicionalProdutividade() {
        return adicionalProdutividade;
    }

    public void setAdicionalProdutividade(double adicionalProdutividade) {
        if (!Double.isFinite(adicionalProdutividade) || adicionalProdutividade < 0) {
            throw new IllegalArgumentException("Adicional de produtividade deve ser não negativo.");
        }
        this.adicionalProdutividade = adicionalProdutividade;
    }

    @Override
    public double calcularRemuneracao() {
        return getSalarioBase() + adicionalProdutividade;
    }

    @Override
    public String exibirInformacoes() {
        return "Administrativo | " + super.exibirInformacoes()
                + String.format(" | Produtividade: R$ %.2f", adicionalProdutividade);
    }
}
