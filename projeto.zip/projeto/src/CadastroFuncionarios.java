import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class CadastroFuncionarios {
    private final List<Funcionario> funcionarios = new ArrayList<>();

    public void cadastrar(Funcionario funcionario) {
        Objects.requireNonNull(funcionario, "Funcionário é obrigatório.");
        if (funcionario.getNome() == null || funcionario.getCpf() == null
                || funcionario.getMatricula() <= 0
                || (funcionario instanceof Desenvolvedor desenvolvedor
                    && desenvolvedor.getNivelExperiencia() == null)) {
            throw new IllegalArgumentException("Preencha os dados obrigatórios antes do cadastro.");
        }
        if (buscar(funcionario.getMatricula()) != null || buscar(funcionario.getCpf()) != null) {
            throw new IllegalArgumentException("CPF ou matrícula já cadastrado.");
        }
        funcionarios.add(funcionario);
    }

    // Sobrecarga: busca por matrícula (int) ou CPF (String).
    public Funcionario buscar(int matricula) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getMatricula() == matricula) {
                return funcionario;
            }
        }
        return null;
    }

    public Funcionario buscar(String cpf) {
        for (Funcionario funcionario : funcionarios) {
            if (funcionario.getCpf().equals(cpf)) {
                return funcionario;
            }
        }
        return null;
    }

    public List<Funcionario> listar() {
        return Collections.unmodifiableList(funcionarios);
    }
}
