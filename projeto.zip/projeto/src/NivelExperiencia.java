public enum NivelExperiencia {
    JUNIOR(0.10),
    PLENO(0.20),
    SENIOR(0.30);

    private final double percentualAdicional;

    NivelExperiencia(double percentualAdicional) {
        this.percentualAdicional = percentualAdicional;
    }

    public double getPercentualAdicional() {
        return percentualAdicional;
    }
}
